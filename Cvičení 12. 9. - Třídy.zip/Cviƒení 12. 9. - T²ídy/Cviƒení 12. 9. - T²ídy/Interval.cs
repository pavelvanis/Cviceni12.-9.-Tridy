﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cvičení_12._9.___Třídy
{
    internal class Interval
    {
        private int max;
        private int min;

        public Interval(int min, int max)
        {
            if (min > max)
            {
                throw new Exception("Spatne zadane hodnoty");
            }
            this.max = max;
            this.min = min;
        }

        public int Min
        {
            get { return min; }

            set {
                if (value < max)
                {
                    min = value;
                }
                else
                {
                    throw new Exception("zadejte mensi hodnotu");
                }
            }
            
        }

        public int Max
        {
            get { return max; }

            set
            {
                if (value > min)
                    {
                    max = value;
                    }
                    else
                    {
                        throw new Exception("zadejte vetsi hodnotu");
                    }
            }
        }

        public Boolean IsIn(int value)
        {
            if(value > min && value < max)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        public static Interval? Prunik(Interval a, Interval b)
        {
            int Min = 0;
            int Max = 0;

            if (a.min >= b.min && a.min <= b.max)
            {
                Min = a.min;
            }
                else
                {
                    Min = b.min;
                }

            if (a.max <= b.max && a.max >= b.min)
            {
                Max = a.max;
            }
                else
                {
                    Max = b.max;
                }

            if (a.min > b.max || b.min > a.max)
            {
                return null;
            }
            else
            {
                return new Interval(Min, Max);
            }

            

        }

    }
}
