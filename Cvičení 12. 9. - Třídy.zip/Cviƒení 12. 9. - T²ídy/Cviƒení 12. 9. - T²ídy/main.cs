﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cvičení_12._9.___Třídy
{
    class main
    {
        public static void Main(string[] args)
        {

            try
            {
                Interval interval1 = new Interval(11, 13);
                Interval interval2 = new Interval(3, 10);

                Interval? i3 = Interval.Prunik(interval1, interval2)
                Console.WriteLine("<" + i3.Min + ";" + i3.Max + ">");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            

        }
    }

}
